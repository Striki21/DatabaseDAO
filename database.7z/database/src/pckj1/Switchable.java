package pckj1;

public interface Switchable {

	public void interfacciaFilesDatabase();

}
